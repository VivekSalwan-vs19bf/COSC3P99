import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.Tree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.SimpleTreeVisitor;
import java.util.Arrays;

//public class Sample1 {
//}
//public class Sample2{
//
//}
public class Calculator {
    // Addition
    public static int add(int num1, int num2) {
        return num1 + num2;
    }
}

    // Subtraction
    public static int subtract(int num1, int num2) {
        return num1 - num2;
    }

    // Multiplication
    public static int multiply(int num1, int num2) {
        return num1 * num2;
    }

    // Division
    public static double divide(double num1, double num2) {
        if (num2 == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return num1 / num2;
    }
}
