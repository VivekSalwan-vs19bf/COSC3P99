import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import com.sun.source.util.SimpleTreeVisitor;

import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * This class parses Java source files and extracts information about classes and methods for documentation generation.
 */
public class Parser {
    // Variables for Java compiler, file manager, compilation units, compilation unit trees, and filename
    JavaCompiler compiler;
    StandardJavaFileManager fileManager;
    Iterable<? extends JavaFileObject> compilationUnits;
    Iterable<? extends CompilationUnitTree> compilationUnitTrees;
    String filename = "src/main/resources/sampleTestCodes/Sample3.java";

    // New variable to hold the collected information
    List<String[]> documentationData = new ArrayList<>();

    /**
     * Constructor for the Parser class.
     * Initializes Java compiler, file manager, and compilation units.
     * Processes files, extracts type declarations, and generates documentation.
     */
    public Parser() {
        compiler = ToolProvider.getSystemJavaCompiler();
        fileManager = compiler.getStandardFileManager(null, null, StandardCharsets.UTF_8);
        compilationUnits = fileManager.getJavaFileObjectsFromFiles(List.of(new File(filename)));
        processFiles(); // Process Java files
        getTypeDecls(); // Extract class and method information
        DocumentationGenerator.generateCSV(documentationData); // Generate CSV documentation
    }

    /**
     * Process Java files using JavacTask and parse compilation units.
     */
    public void processFiles() {
        JavacTask javacTask = (JavacTask) compiler.getTask(null, fileManager, null, null, null, compilationUnits);
        try {
            compilationUnitTrees = javacTask.parse();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Extract type declarations (classes and methods) from compilation units.
     * Collects class names, method names, return types, and parameters for documentation generation.
     */
    public void getTypeDecls() {
        for (CompilationUnitTree compilationUnitTree : compilationUnitTrees) {
            for (Tree tree : compilationUnitTree.getTypeDecls()) {
                tree.accept(new SimpleTreeVisitor<Void, Void>() {
                    @Override
                    public Void visitClass(ClassTree classTree, Void aVoid) {
                        // Collect basic class information
                        String className = classTree.getSimpleName().toString();
                        String extendsClause = classTree.getExtendsClause() != null ? classTree.getExtendsClause().toString() : "None";
                        String implementsClause = classTree.getImplementsClause().toString();

                        // Collect methods information
                        for (Tree member : classTree.getMembers()) {
                            member.accept(new SimpleTreeVisitor<Void, Void>() {
                                @Override
                                public Void visitMethod(MethodTree methodTree, Void aVoid) {
                                    String methodName = methodTree.getName().toString();
                                    // Check if the method is a constructor
                                    boolean isConstructor = methodTree.getReturnType() == null;
                                    String returnType = isConstructor ? "Constructor" : methodTree.getReturnType().toString();
                                    String parameters = methodTree.getParameters().toString();

                                    // Add collected information to the list
                                    documentationData.add(new String[]{className, methodName, returnType, parameters});
                                    return null;
                                }
                            }, null);
                        }
                        return null;
                    }
                }, null);
            }
        }
    }
}
