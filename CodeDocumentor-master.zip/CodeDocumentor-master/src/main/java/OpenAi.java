import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * This class represents a controller for interacting with the OpenAI API.
 */
@RestController
public class OpenAi {
    private final String API_URL; // URL for the OpenAI API
    private final HttpHeaders headers; // HTTP headers for API requests
    private final RestTemplate restTemplate; // Object for making HTTP requests
    private final String model; // Model name used for queries

    /**
     * Constructor for the OpenAi class.
     * Initializes API_URL, headers, RestTemplate, and model with values provided through dependency injection.
     * @param apiUrl The URL for the OpenAI API.
     * @param authToken The authentication token for accessing the API.
     * @param model The name of the model used for queries.
     */
    public OpenAi(@Value("${API_URL}") String apiUrl, @Value("${AUTH_TOKEN}") String authToken, @Value("${MODEL}")String model) {
        this.API_URL = apiUrl;
        this.model=model;

        // Set up HTTP headers
        this.headers = new HttpHeaders();
        this.headers.setContentType(MediaType.APPLICATION_JSON);
        this.headers.setBearerAuth(authToken);

        // Initialize RestTemplate for making HTTP requests
        this.restTemplate = new RestTemplate();
    }

    /**
     * Queries the OpenAI model with the provided prompt and retrieves the response.
     * @param prompt The prompt to be sent to the OpenAI model.
     * @return A JSONObject containing the response from the OpenAI model.
     */
    public JSONObject queryModel(String prompt) {
        // Prepare request body
        String requestBody = "{\"model\": \"" + this.model + "\", \"messages\": [{\"role\": \"user\", \"content\": \"" + prompt + "\"}]}";
        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);

        // Send HTTP POST request to OpenAI API
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                API_URL, HttpMethod.POST, requestEntity, String.class);

        // Check if request was successful
        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            // Parse response JSON
            JSONArray jsonArray = new JSONArray(responseEntity.getBody());
            JSONObject jsonObject = jsonArray.getJSONObject(0);

            // Return the response
            return jsonObject;
        } else {
            // Return null if request was not successful
            return null;
        }
    }
}
