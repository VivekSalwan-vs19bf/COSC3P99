import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * This class is responsible for generating documentation in CSV format.
 */
public class DocumentationGenerator {

    /**
     * Generates a CSV file containing documentation for classes, methods, return types, and parameters.
     * @param data A list of String arrays where each array represents a line of data to be written to the CSV file.
     */
    public static void generateCSV(List<String[]> data) {
        // Define the name of the CSV file
        String csvFile = "documentation.csv";
        try (FileWriter writer = new FileWriter(csvFile)) {
            // Write the header line for the CSV file
            writer.append("Class Name,Method Name,Return Type,Parameters\n");
            // Iterate through each line of data and write it to the CSV file
            for (String[] lineData : data) {
                writer.append(String.join(",", lineData)); // Join elements of the array with commas to form a line
                writer.append("\n"); // Add a newline character after each line of data
            }
            // Print a success message to the console
            System.out.println("Documentation CSV file has been created successfully.");
        } catch (IOException e) {
            // Print any IOExceptions that occur during file writing
            e.printStackTrace();
        }
    }
}