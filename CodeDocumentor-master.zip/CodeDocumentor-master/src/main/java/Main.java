import org.json.JSONArray;
import org.json.JSONObject;
/**
 * This class serves as the entry point for the application.
 */
public class Main {
    public static void main(String[] args) {

        // {"course":[{"id":3,"information":"test","name":"course1"}],"name":"student"}

        //new Parser();
        new Parser();

        //test("How are you doing?");
        //OpenAi openAi = new OpenAi("https://api.openai.com/v1/chat/completions","oAvuJOwpTwyvCxKG8qrwT3BlbkFJhQKCr6Ms8UiSqOGhUsRr","gpt-3.5-turbo");
        //openAi.queryModel("Hello how are you doing?");
        //System.out.println(new ChatGPTAPIExample().chatGPT("Hello how are you?"));
        //new ChatGPTAPIExample().createJson2("gpt-3.5-turbo", "Hello how are you?", "System prompt");

    }
}
